A Pen created at CodePen.io. You can find this one at https://codepen.io/babyboomer53/pen/534d6e302a6399e9c90f01e5b820799c.

 