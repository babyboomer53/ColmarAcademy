A Pen created at CodePen.io. You can find this one at https://codepen.io/babyboomer53/pen/5657782a19a7cd46ef55114ca5a5261b.

 