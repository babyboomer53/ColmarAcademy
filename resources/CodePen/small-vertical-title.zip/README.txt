A Pen created at CodePen.io. You can find this one at https://codepen.io/babyboomer53/pen/610e0bbc1a59ed7d9a8059aba2ed9d34.

 